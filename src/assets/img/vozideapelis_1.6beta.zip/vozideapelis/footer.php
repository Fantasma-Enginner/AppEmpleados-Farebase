		<div id="footer-bar">
			<?php if ( ! dynamic_sidebar( 'footerbar' ) ) :
				  endif; ?><div class="clearfix"></div>
		</div>
		<div id="footer">
			<div class="footer-text">
				Copyright © 2014 <a href="<?php bloginfo('url'); ?>"><?php bloginfo('name'); ?></a> - Todos los derechos reservados. Diseño original por <a href="https://github.com/Zeokat/vozideatheme">Vozidea</a>.<br/>
<a href="<?php bloginfo('url'); ?>"><?php bloginfo('name'); ?></a> No Aloja Ningún Archivo En Sus Servidores, Todo Contenido De La Web Hace Referencia a Servidores Externos.
			</div>
		</div>
	</div>
</div>
	<?php wp_footer(); ?>
	<!-- No olvides Google analytics -->
</body>
</html>