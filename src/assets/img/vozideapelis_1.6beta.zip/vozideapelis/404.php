<?php get_header(); ?>

<div id="content">
	<div id="colCenter">
		<div class="entry-wrap">
			<div class="entry-header">
				<div class="post-title">Pagina no encontrada</div>
			</div>
			<div class="entry"><h2>Error 404 - Page Not Found</h2></div>
			<div class="clearfix"></div>
		</div>
	</div>
	<div id="colRight"><?php get_sidebar(); ?></div>
</div>
<div class="film-line"></div>

<?php get_footer(); ?>
