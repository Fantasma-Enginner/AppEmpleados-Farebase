---------------Plugins necesarios--------------------
El template hace uso de los siguientes plugins para su correcto funcionamiento:
- WP-Pagenavi (plugin de paginaci�n, el tema incluye css integrado para el plugin).




---------------Plugins recomendados--------------------
Contact Form 7 (para crear una p�gina de contacto).
Google XML Sitemaps.
WordPress SEO by Yoast (o plugin de SEO similar con el que est�s familiarizado).