    <?php if (function_exists('dynamic_sidebar') && dynamic_sidebar('Sidebar-1')) : else : ?>
    
        <!-- All this stuff in here only shows up if you DON'T have any widgets active in this zone -->

    	<h2>Informacion</h2>
    	<ul>
    		<li>Agrega widgets desde el panel de administracion</li>
    	</ul>
	
	<?php endif; ?>